create definer = root@`%` trigger trg_pacienti_after_update
    after update
    on Pacienti
    for each row
BEGIN
    INSERT INTO user_log (id_pacient, action, detalii)
    VALUES (OLD.id_pacient, 'UPDATE_PACIENT', CONCAT('S-au modificat datele pentru pacientul cu CNP: ', OLD.cnp));
END;

