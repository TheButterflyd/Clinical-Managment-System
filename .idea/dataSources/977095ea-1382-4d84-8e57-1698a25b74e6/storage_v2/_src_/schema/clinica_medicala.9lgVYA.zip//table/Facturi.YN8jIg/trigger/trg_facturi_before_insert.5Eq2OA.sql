create definer = root@`%` trigger trg_facturi_before_insert
    before insert
    on Facturi
    for each row
BEGIN
    IF NEW.Suma <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Suma facturii trebuie sa fie mai mare decat 0';
    END IF;
END;

